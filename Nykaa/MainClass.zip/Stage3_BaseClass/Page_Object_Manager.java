package com.Stage3_BaseClass;

import com.Stage2_BaseClass.Login_01Implements;

public class Page_Object_Manager extends Login_01Implements{
			
		public Login_WebElements_Implements pom ;		// Login_WebElements_Implements pom = new Login_WebElements_Implements();
		public DataConf_Reader DCM;						// DataConf_Reader DCM = new DataConf_Reader();
		public static Page_Object_Manager pom_mag;
			
			public Login_WebElements_Implements getPom() {
				if (pom == null) {
				pom = new Login_WebElements_Implements();
				}
				return pom;
			}

			public DataConf_Reader getDCM() {
				if (DCM == null) {
				DCM = new DataConf_Reader();
				}
				return DCM;
			}
			public static Page_Object_Manager getPom_mag() {
				if (pom_mag == null) {
					pom_mag = new Page_Object_Manager();
				}
			return pom_mag;
			}

}
