package com.Stage3_BaseClass;

public interface Login_WebElements_Interface {
	String  Xpath_SignIn_btn = "//button[text()='Sign in']";
	String Xpath_SignMobile_btn = "//button[text()='Sign in with Mobile / Email']";
	String Xpath_MbInputBox = "emailMobile";
	String Xpath_ProceedBtn = "submitVerification";
	String Xpath_otpField = "otpField";
	String Xpath_verifyBtn = "//button[text()='verify']";
}
